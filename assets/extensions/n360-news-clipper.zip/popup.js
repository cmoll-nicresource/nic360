import { apiFetch, domainOf, getSettings, isSignedIn } from './shared.js';
import { matchLocationHints } from './locationMatching.js';

const signedOutView = document.getElementById('signedOutView');
const loadingView = document.getElementById('loadingView');
const clipForm = document.getElementById('clipForm');
const resultAlert = document.getElementById('resultAlert');
const titleInput = document.getElementById('titleInput');
const excerptInput = document.getElementById('excerptInput');
const sourceDomainText = document.getElementById('sourceDomainText');
const sourceUrlLink = document.getElementById('sourceUrlLink');
const submitButton = document.getElementById('submitButton');
const sourceDateInput = document.getElementById('sourceDateInput');
const imageUrlInput = document.getElementById('imageUrlInput');
const previewImage = document.getElementById('previewImage');
const locationsInput = document.getElementById('locationsInput');
const locationSearch = document.getElementById('locationSearch');
const locationHint = document.getElementById('locationHint');
let locations = [];
const selectedLocations = new Set();

function renderLocations() {
	const term = locationSearch.value.toLowerCase();
	locationsInput.replaceChildren();
	for (const location of locations.filter(location => selectedLocations.has(location.id) || location.label.toLowerCase().includes(term))) {
		const option = document.createElement('option');
		option.value = String(location.id); option.textContent = location.label;
		option.selected = selectedLocations.has(location.id); locationsInput.appendChild(option);
	}
}
locationSearch.addEventListener('input', renderLocations);
locationsInput.addEventListener('change', () => {
	for (const option of locationsInput.options) {
		if (option.selected) selectedLocations.add(Number(option.value));
		else selectedLocations.delete(Number(option.value));
	}
});
imageUrlInput.addEventListener('input', () => {
	try {
		const url = new URL(imageUrlInput.value);
		if (url.protocol !== 'https:') throw Error();
		previewImage.src = url.href; previewImage.classList.remove('hidden');
	} catch { previewImage.removeAttribute('src'); previewImage.classList.add('hidden'); }
});

let extracted = null;

function showResult(message, kind, linkUrl, linkText) {
	resultAlert.className = `alert ${kind} text-sm flex-col items-start gap-1`;
	resultAlert.innerHTML = '';

	const line = document.createElement('div');
	line.textContent = message;
	resultAlert.appendChild(line);

	if (linkUrl) {
		const link = document.createElement('a');
		link.href = linkUrl;
		link.target = '_blank';
		link.rel = 'noopener';
		link.className = 'link font-semibold';
		link.textContent = linkText || 'Open it';
		resultAlert.appendChild(link);
	}

	resultAlert.classList.remove('hidden');
}

async function extractActiveTab() {
	const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
	if (!tab?.id) throw new Error('No active tab.');

	await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['contentScript.js'] });
	const [{ result }] = await chrome.scripting.executeScript({
		target: { tabId: tab.id },
		func: () => window.__nicClipExtract(),
	});
	return result;
}

async function init() {
	const settings = await getSettings();
	if (!isSignedIn(settings)) {
		loadingView.classList.add('hidden');
		signedOutView.classList.remove('hidden');
		return;
	}

	try {
		extracted = await extractActiveTab();
		titleInput.value = extracted.title || '';
		excerptInput.value = extracted.excerptText || extracted.description || '';
		sourceDateInput.value = extracted.publishedTime || '';
		document.getElementById('descriptionText').textContent = extracted.description || 'No social description found.';
		imageUrlInput.value = extracted.imageUrl?.startsWith('https://') ? extracted.imageUrl : '';
		imageUrlInput.dispatchEvent(new Event('input'));
		try {
			locations = (await apiFetch('/api/extension/locations')).locations;
			const suggestions = matchLocationHints(extracted.locationHints || [], locations);
			suggestions.ids.forEach(id => selectedLocations.add(id));
			renderLocations();
			locationHint.textContent = suggestions.unmatched.length
				? `Check these unmatched places manually: ${suggestions.unmatched.join('; ')}`
				: suggestions.ids.length ? 'Review the selected locations before saving.' : 'No location was detected. Choose a location if known.';
		} catch {
			locationHint.textContent = 'Could not load locations. You can still save a draft and add locations in the CMS.';
		}
		sourceDomainText.textContent = domainOf(extracted.url) || extracted.siteName || '(unknown)';
		sourceUrlLink.textContent = extracted.url;
		sourceUrlLink.href = extracted.url;

		loadingView.classList.add('hidden');
		clipForm.classList.remove('hidden');
	} catch (err) {
		loadingView.classList.add('hidden');
		showResult(`Couldn't read this page: ${err.message}`, 'alert-error');
	}
}

document.getElementById('openOptionsButton')?.addEventListener('click', () => {
	chrome.runtime.openOptionsPage();
});

document.getElementById('viewRecentLink')?.addEventListener('click', async (event) => {
	event.preventDefault();
	const win = await chrome.windows.getCurrent();
	chrome.sidePanel.open({ windowId: win.id });
});

clipForm.addEventListener('submit', async (event) => {
	event.preventDefault();
	submitButton.disabled = true;
	resultAlert.classList.add('hidden');

	try {
		const data = await apiFetch('/api/extension/articles', {
			method: 'POST',
			body: JSON.stringify({
				title: titleInput.value,
				excerptText: excerptInput.value,
				sourceUrl: extracted.url,
				sourceDomain: domainOf(extracted.url),
				sourceDate: sourceDateInput.value.trim() || undefined,
				socialPreview: { description: extracted.description || '', imageUrl: imageUrlInput.value.trim() || undefined },
				locationIds: [...selectedLocations],
			}),
		});

		if (data.duplicate) {
			showResult('This link was already clipped.', 'alert-info', data.editUrl, 'View existing draft');
		} else {
			showResult('Saved as a draft.', 'alert-success', data.editUrl, 'Review & publish');
		}
	} catch (err) {
		showResult(err.message, 'alert-error');
	} finally {
		submitButton.disabled = false;
	}
});

init();
