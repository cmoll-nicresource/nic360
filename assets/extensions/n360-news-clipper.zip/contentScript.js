// contentScript.js — NOT a standing content script (nothing in manifest.json
// injects this on every page load anymore). popup.js injects it on demand via
// chrome.scripting.executeScript({files: ['contentScript.js']}) only when the
// user opens the extension on a tab, then invokes the function it defines
// with a second executeScript call (a `files` injection can't return a value
// directly, so this two-step inject-then-invoke is the standard way to get
// one back).

function nicClipExtract() {
	function metaContent(selectors) {
		for (const selector of selectors) {
			const content = document.querySelector(selector)?.getAttribute('content');
			if (content) return content;
		}
		return '';
	}

	function cleanText(text) {
		return typeof text === 'string' ? text.replace(/\s+/g, ' ').trim() : '';
	}

	// Only Article nodes: a publisher's Organization/address is not the story location.
	const articles = [];
	function visit(node, depth = 0) {
		if (!node || typeof node !== 'object' || depth > 12) return;
		if (Array.isArray(node)) { node.forEach(child => visit(child, depth + 1)); return; }
		if ([].concat(node['@type'] || []).some(type => /^(?:https?:\/\/schema\.org\/)?(?:NewsArticle|Article|ReportageNewsArticle|AnalysisNewsArticle|BlogPosting|ScholarlyArticle)$/.test(type))) articles.push(node);
		if (node['@graph']) visit(node['@graph'], depth + 1);
		if (node.mainEntity) visit(node.mainEntity, depth + 1);
	}
	for (const element of document.querySelectorAll('script[type="application/ld+json"]')) {
		if (element.textContent.length > 1000000) continue;
		try { visit(JSON.parse(element.textContent)); } catch { /* Try the other metadata. */ }
	}
	function absoluteUrl(value) {
		if (!value || typeof value !== 'string') return '';
		try {
			const url = new URL(value, location.href);
			return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password ? url.href : '';
		} catch { return ''; }
	}
	const canonical = absoluteUrl(document.querySelector('link[rel="canonical"]')?.getAttribute('href') || metaContent(['meta[property="og:url"]']) || location.href);
	const data = articles.find(article => [article.url, article.mainEntityOfPage, article.mainEntityOfPage?.['@id'], article['@id']]
		.some(url => typeof url === 'string' && absoluteUrl(url).split('#')[0] === canonical.split('#')[0])) || articles[0] || {};
	const title = metaContent(['meta[property="og:title"]', 'meta[name="twitter:title"]']) || cleanText(data.headline) || cleanText(data.name) || document.querySelector('article h1, main h1, h1')?.textContent || document.title || '';
	const description = metaContent([
		'meta[property="og:description"]',
		'meta[name="description"]',
		'meta[name="twitter:description"]',
	]) || (typeof data.description === 'string' ? data.description : '');
	const timeNodes = [...document.querySelectorAll('article time[datetime], main time[datetime], time[itemprop="datePublished"], time[pubdate]')];
	if (!timeNodes.length && document.querySelectorAll('time[datetime]').length === 1) timeNodes.push(document.querySelector('time[datetime]'));
	const publishedNode = timeNodes.find(node => !/updated|modified/i.test(node.getAttribute('itemprop') || '') && !/updated|modified/i.test(node.className + ' ' + node.textContent));
	const dateCandidates = [metaContent(['meta[property="article:published_time"]']), data.datePublished,
		...['datePublished', 'date', 'publish-date', 'pubdate', 'parsely-pub-date', 'sailthru.date'].map(name => metaContent([`meta[name="${name}"]`])),
		document.querySelector('[itemprop="datePublished"]')?.getAttribute('content'),
	document.querySelector('[itemprop="datePublished"]')?.getAttribute('datetime'),
		publishedNode?.getAttribute('datetime')];
	function validDate(value) {
		if (typeof value !== 'string') return '';
		value = value.trim();
		if (!/^(?:\d{4}-\d{2}-\d{2}(?:[T\s]|$)|[A-Za-z]+\s+\d{1,2},?\s+\d{4})/.test(value)) return '';
		const date = new Date(value);
		return Number.isNaN(date.getTime()) ? '' : /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : date.toISOString();
	}
	const publishedTime = dateCandidates.map(validDate).find(Boolean) || '';
	function imageValue(value, depth = 0) {
		if (depth > 8) return '';
		return typeof value === 'string' ? value : Array.isArray(value) ? imageValue(value[0], depth + 1) : value?.url || value?.contentUrl || '';
	}
	const imageUrl = absoluteUrl(metaContent(['meta[property="og:image:secure_url"]', 'meta[property="og:image"]', 'meta[name="twitter:image"]', 'meta[name="twitter:image:src"]']) || imageValue(data.image));
	const locationHints = [];
	function countryName(value) {
		if (typeof value !== 'string') return '';
		if (!/^[A-Za-z]{2}$/.test(value)) return value;
		try { return new Intl.DisplayNames(['en'], { type: 'region' }).of(value.toUpperCase()) || value; } catch { return value; }
	}
	function addPlace(value) {
		if (Array.isArray(value)) { value.forEach(addPlace); return; }
		if (typeof value === 'string') { if (value.trim()) locationHints.push(cleanText(value)); return; }
		if (!value || typeof value !== 'object') return;
		if (value.address && typeof value.address === 'object') {
			const address = value.address;
			const country = countryName(typeof address.addressCountry === 'object' ? address.addressCountry.name : address.addressCountry);
			const parts = [address.addressLocality, address.addressRegion, country].filter(v => typeof v === 'string' && v.trim());
			if (parts.length) { locationHints.push(parts.join(', ')); return; }
		}
		if (value.name) addPlace(value.name);
	}
	addPlace(data.contentLocation);
	addPlace(data.locationCreated);
	addPlace(metaContent(['meta[name="geo.placename"]']));
	addPlace(metaContent(['meta[name="geo.region"]']));
	const geoRegion = metaContent(['meta[name="geo.region"]']);
	if (/^[A-Za-z]{2}(?:-[A-Za-z0-9]+)?$/.test(geoRegion)) addPlace(countryName(geoRegion.slice(0, 2)));
	const siteName = metaContent(['meta[property="og:site_name"]']) || location.hostname;

	// og:description alone is usually a thin marketing blurb. Try to pull
	// something closer to the actual article text for a more useful starting
	// excerpt — the editor reviews and trims this before publishing anyway.
	let bodyText = cleanText(document.querySelector('article')?.innerText || '');
	if (bodyText.length < 200) {
		bodyText = cleanText(document.querySelector('main')?.innerText || '');
	}
	if (bodyText.length < 200) {
		bodyText = Array.from(document.querySelectorAll('p'))
			.map((p) => cleanText(p.innerText))
			.filter((text) => text.length > 40)
			.slice(0, 15)
			.join(' ');
	}

	const excerptText = (description || bodyText || '').slice(0, 10000);

	return {
		title: cleanText(title),
		description: cleanText(description),
		imageUrl,
		locationHints: [...new Set(locationHints)].slice(0, 20),
		excerptText,
		publishedTime,
		siteName: cleanText(siteName),
		url: canonical || location.href,
	};
}

window.__nicClipExtract = nicClipExtract;
