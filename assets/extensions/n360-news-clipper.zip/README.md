﻿# N360 News Clipper 2.2.1

Connect through your normal Nicotine360 website sign-in. In extension options choose **Connect to Nicotine360**, then approve this browser. The beta site is already configured; no endpoint or password is entered in the extension.

**Upgrading from 2.1 or older:** sign out of the old extension first to clear its synced credential, remove that extension in `chrome://extensions`, then extract this package to a persistent folder and use **Load unpacked** with Developer mode enabled. This release establishes a stable Chrome ID, so removal/reinstallation is needed once. Later versions preserving this ID can use Reload.

Connections last 12 hours and are stored only on this device. Use **Disconnect this browser**, or **Connected browsers** in your staff workspace, to revoke access early. If a disconnect request fails while offline, reconnect to the network and retry. Signing out of the website does not disconnect an approved clipper.

On a news page, click the extension, review the title, excerpt, date, image URL and existing location tags, then **Save as draft**. Social preview text initializes the excerpt; article text is a fallback. Original preview text and image URL remain separately preserved. Missing/ambiguous metadata needs manual review. Subjects/products and publishing remain CMS tasks; no taxonomy is created. Paywalls and protected Chrome pages may prevent extraction.

The server must have both `migration/extensionSocialPreview.sql` and `migration/extensionConnections.sql`, plus the 2.2 connection endpoints. Its callback allowlist must match this manifest's public key/Chrome ID. The opaque credential only works on clipper routes, not the full CMS API. It is hashed on the server and invalidated by expiry, revocation, account lockout/deletion or password change. Local storage is device-only but can still be accessed by someone controlling your Chrome profile.

## Development checks

Run `npm ci`, `npx playwright install chromium`, `npm test`, and `npm run build`. Ten Chromium checks cover extraction, popup metadata review and the connection flow with mocked Chrome APIs. PostgreSQL/browser authorization tests live in the parent Nic360 project. This separate repository has an unrelated upstream; pushing the CMS does not publish the extension.
