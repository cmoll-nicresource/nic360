import { apiFetch, getSettings, isSignedIn } from './shared.js';

const signedOutView = document.getElementById('signedOutView');
const errorAlert = document.getElementById('errorAlert');
const clipsList = document.getElementById('clipsList');

async function load() {
	errorAlert.classList.add('hidden');
	clipsList.innerHTML = '';

	const settings = await getSettings();
	if (!isSignedIn(settings)) {
		signedOutView.classList.remove('hidden');
		return;
	}
	signedOutView.classList.add('hidden');

	try {
		const { articles } = await apiFetch('/api/extension/articles');

		if (articles.length === 0) {
			const empty = document.createElement('li');
			empty.className = 'text-sm opacity-70';
			empty.textContent = 'No clips yet.';
			clipsList.appendChild(empty);
			return;
		}

		for (const article of articles) {
			const item = document.createElement('li');
			item.className = 'card card-compact bg-base-200 p-3';

			const link = document.createElement('a');
			link.href = article.editUrl;
			link.target = '_blank';
			link.rel = 'noopener';
			link.className = 'link font-semibold text-sm';
			link.textContent = article.title;

			const meta = document.createElement('div');
			meta.className = 'text-xs opacity-70 mt-1';
			const statusLabel = article.status === 'draft' ? 'Draft' : 'Published';
			meta.textContent = `${statusLabel} — ${new Date(article.createdAt).toLocaleString()}`;

			item.append(link, meta);
			clipsList.appendChild(item);
		}
	} catch (err) {
		errorAlert.textContent = err.message;
		errorAlert.classList.remove('hidden');
	}
}

document.getElementById('refreshButton').addEventListener('click', load);
load();
