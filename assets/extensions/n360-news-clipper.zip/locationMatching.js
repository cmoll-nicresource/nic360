const normalize = value => String(value || '').normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
const aliases = { us: 'united states', usa: 'united states', 'united states of america': 'united states', uk: 'united kingdom' };

/** Match explicit place names, with ancestor context to disambiguate names.
 * Never guess a place from free article text or the publisher's headquarters. */
export function matchLocationHints(hints, locations) {
	const selected = new Set(), unmatched = [];
	const byId = new Map(locations.map(location => [location.id, location]));
	for (const hint of hints || []) {
		// geo.region uses ISO codes. Country-only codes are safe; subdivisions
		// remain unmatched rather than confusing US-CA with Canada.
		const parts = String(hint).split(/[,›]/).map(normalize).filter(Boolean).map(part => aliases[part] || part);
		let candidates = locations.filter(location => normalize(location.name) === parts[0]);
		if (parts.length > 1) candidates = candidates.filter(location => {
			const ancestors = [], seen = new Set([location.id]);
			let parent = location.parent;
			while (parent && !seen.has(parent)) {
				seen.add(parent); const ancestor = byId.get(parent); if (!ancestor) break;
				ancestors.push(normalize(ancestor.name)); parent = ancestor.parent;
			}
			return parts.slice(1).every(part => ancestors.includes(part));
		});
		if (candidates.length === 1) selected.add(candidates[0].id);
		else {
			// A city not in the CMS can still identify an unambiguous country/state.
			let found = false;
			for (const part of parts.slice(1)) {
				const matches = locations.filter(location => normalize(location.name) === part && location.level === 'country');
				if (matches.length === 1) { selected.add(matches[0].id); found = true; }
			}
			if (!found) unmatched.push(hint);
		}
	}
	return { ids: [...selected], unmatched };
}
